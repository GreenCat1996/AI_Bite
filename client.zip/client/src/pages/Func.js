const Func = () => {
  const sendEmail = () => {
    // Define the recipient, subject, and body of the email
    var recipient = 'xkickai@gmail.com';
    var subject = 'Your Subject Here';
    var body = 'This is the body of the email.';

    // Construct the email link
    var link =
      'mailto:' +
      recipient +
      '?subject=' +
      encodeURIComponent(subject) +
      '&body=' +
      encodeURIComponent(body);

    // Open the link in a new window
    window.open(link, '_blank');
  };
  return (
    <div className="footer">
      <button className="btn btn-primary" onClick={sendEmail}>
        Draft a post-call email
      </button>
      <button
        className="btn btn-danger"
        style={{ margin: '0 2rem' }}
        onClick={() => {
          window.open('http://www.google.com');
        }}
      >
        Open transcript
      </button>
    </div>
  );
};

export default Func;
