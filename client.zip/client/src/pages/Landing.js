// import { MdMoreVert } from 'react-icons/md';
import { useState } from 'react';
import './app.css';
import './bootstrap.min.css';

import Func from './Func';
import Gong from './Gong';

const Landing = () => {
  const [showMenu, setShowMenu] = useState(false);

  const onClickMenu = () => {
    console.log('Menu Clicked');
    setShowMenu((prev) => !prev);
    console.log(showMenu);
  };
  const calendar = ['9-10 AM', '10-10.30 AM', '12-1 AM', '2-3 AM', '4-5 AM'];
  const [index, setIndex] = useState(0);

  const onChange = (e) => {
    // setCalendar({ ...calendar, i: e.target.value });
    setIndex(parseInt(e.target.value));
  };
  return (
    <section className="landing">
      <div className="main">
        <div className="title">
          <h1>A E</h1>
          <p className="topic">Sales AI Co-pilot</p>
        </div>
        <div className="settings">
          <i className="fas fa-ellipsis-h" id="dot" onClick={onClickMenu} />
          <Gong showMenu={showMenu} setShowMenu={setShowMenu} />
        </div>
      </div>
      <div className="header">
        <div>
          <div className="checkbox-circle">
            <input
              type="checkbox"
              id="option1"
              className="checkbox"
              value="1"
              onChange={onChange}
            />
            <label for="option1"></label>
            <div className="para">
              {' '}
              9-10 AM<div className="para">Callie @DnB Inc.</div>
            </div>
          </div>
          <div className="checkbox-circle">
            <input
              type="checkbox"
              id="option2"
              className="checkbox"
              onChange={onChange}
              value="2"
            />
            <label for="option2"></label>
            <div className="para">
              {' '}
              10-10.30 AM<div className="para">Ram @Plc Inc.</div>
            </div>
          </div>
          <div className="checkbox-circle">
            <input
              type="checkbox"
              id="option3"
              className="checkbox"
              onChange={onChange}
              value="3"
            />
            <label for="option3"></label>
            <div className="para">
              {' '}
              12-1 PM<div className="para">Greg @pio Inc.</div>
            </div>
          </div>
          <div className="checkbox-circle">
            <input
              type="checkbox"
              id="option4"
              className="checkbox"
              onChange={onChange}
              value="4"
            />
            <label for="option4"></label>
            <div className="para">
              {' '}
              2-3 AM<div className="para">Brittany @ABC Paint.</div>
            </div>
          </div>
          <div className="checkbox-circle">
            <input
              type="checkbox"
              id="option5"
              className="checkbox"
              onChange={onChange}
              value="5"
            />
            <label for="option5"></label>
            <div className="para">
              4-5 AM<div className="para">Jane @West Elm.</div>
            </div>
          </div>
        </div>
      </div>
      <hr className="middle" />

      <div className="calendar">
        <i className="fas fa-chevron-left" id="arrow" />
        <div style={{ display: 'flex', margin: ' 0 2rem' }}>
          <p>Last Call : </p>
          <p id="label-text">{calendar[index - 1]}</p>
          <p className="para"> @ 08/01/23</p>
        </div>
        <i className="fas fa-chevron-right" id="arrow" />
      </div>
      <div id="email-text">
        <div>
          <h4>Call Summary:</h4>
          <ul>
            <li>
              {' '}
              We discussed the features and caliabilities of our IoT software
              platfrom in detail
            </li>
          </ul>
        </div>
        <div>
          <h4>Actionable items:</h4>
          <ul>
            <li>
              {' '}
              Please review the attached proposal,which includes pricing details
              and a breakdown of the feautres you requested.
            </li>
            <li>
              {' '}
              Incorporae the proposal into your next steps and decision-makeing
              process.
            </li>
          </ul>
        </div>
        <div>
          <h4>AI Bites:</h4>
          <ul>
            <li> Not worth pursuing; in stead focus on ABC Paint customer</li>
          </ul>
        </div>
      </div>
      <Func />
    </section>
  );
};

export default Landing;
